import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object GitHubClient {
    private val api: GitHubApi = Retrofit.Builder()
        .baseUrl("https://api.github.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(GitHubApi::class.java)

    fun getUser(username: String): GitHubUser? {
        val response = api.getUser(username).execute()
        return if (response.isSuccessful) response.body() else null
    }

    fun getUserRepos(username: String): List<Repository> {
        val response = api.getUserRepos(username).execute()
        return response.body() ?: emptyList()
    }
}
