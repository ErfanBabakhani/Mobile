import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
//
//object GitHubClient {
//    private val api: GitHubApi = Retrofit.Builder()
//        .baseUrl("https://api.github.com/")
//        .addConverterFactory(GsonConverterFactory.create())
//        .build()
//        .create(GitHubApi::class.java)
//
//    fun getUser(username: String): GitHubUser? {
//        val response = api.getUser(username).execute()
//        return if (response.isSuccessful) response.body() else null
//    }
//
//    fun getUserRepos(username: String): List<Repository> {
//        val response = api.getUserRepos(username).execute()
//        return response.body() ?: emptyList()
//    }
//}
object GitHubClient {
    private val api: GitHubApi = Retrofit.Builder()
        .baseUrl("https://api.github.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(GitHubApi::class.java)

    fun getUser(username: String): GitHubUser? {
        return try {
            val response = api.getUser(username).execute()
            if (response.isSuccessful) {
                response.body()
            } else {
                println("HTTP error: ${response.code()} - ${response.message()}")
                null
            }
        } catch (e: Exception) {
            println("Network error while fetching user: ${e.localizedMessage}")
            null
        }
    }

    fun getUserRepos(username: String): List<Repository> {
        return try {
            val response = api.getUserRepos(username).execute()
            if (response.isSuccessful) {
                response.body() ?: emptyList()
            } else {
                println("HTTP error: ${response.code()} - ${response.message()}")
                emptyList()
            }
        } catch (e: Exception) {
            println("Network error while fetching repos: ${e.localizedMessage}")
            emptyList()
        }
    }
}
