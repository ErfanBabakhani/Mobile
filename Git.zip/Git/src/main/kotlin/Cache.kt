object Cache {
    private val users = mutableMapOf<String, GitHubUser>()
    private val repos = mutableMapOf<String, List<Repository>>()

    fun getUser(username: String) = users[username]
    fun saveUser(user: GitHubUser) { users[user.login] = user }

    fun getRepos(username: String) = repos[username] ?: emptyList()
    fun saveRepos(username: String, repoList: List<Repository>) { repos[username] = repoList }

    fun listUsers() = users.keys.toList()
    fun searchUser(query: String) = users.values.filter { it.login.contains(query, ignoreCase = true) }
    fun searchRepo(query: String) = repos.values.flatten().filter { it.name.contains(query, ignoreCase = true) }
}
