fun main() {
    while (true) {
        println("\nMenu:")
        println("1 Get user info")
        println("2 Show cached users")
        println("3 Search user")
        println("4 Search repository")
        println("5 Exit")

        when (readln()) {
            "1" -> fetchUserInfo()
            "2" -> listUsers()
            "3" -> searchUser()
            "4" -> searchRepo()
            "5" -> return
            else -> println("Invalid option!")
        }
    }
}

fun fetchUserInfo() {
    print("Enter GitHub username: ")
    val username = readln().trim()

    Cache.getUser(username)?.let {
        println("Cached user data: $it")
        val cachedRepos = Cache.getRepos(username)
        println("Cached Repositories (${cachedRepos.size}):")
        cachedRepos.forEach { repo -> println("    ${repo.name} - ${repo.html_url}") }
        return
    }

    val user = GitHubClient.getUser(username)
    if (user != null) {
        Cache.saveUser(user)
        println("Retrieved user: $user")

        val repos = GitHubClient.getUserRepos(username)
        Cache.saveRepos(username, repos)
        println("Retrieved Repositories (${repos.size}):")
        repos.forEach { repo -> println("    ${repo.name} - ${repo.html_url}") }
    } else {
        println("User not found!")
    }
}

fun listUsers() {
    println("Cached users: ${Cache.listUsers()}")
}

fun searchUser() {
    print("Enter username to search: ")
    val query = readln().trim()
    val results = Cache.searchUser(query)

    if (results.isEmpty()) println("No users found.")
    else results.forEach {
        println(it)
        val cachedRepos = Cache.getRepos(it.login)
        println("Cached Repositories (${cachedRepos.size}):")
        cachedRepos.forEach { repo -> println("    ${repo.name} - ${repo.html_url}") }
    }
}

fun searchRepo() {
    print("Enter repository name: ")
    val query = readln().trim()

    // Find users who have a repo matching the query
    val matchingUsers = Cache.listUsers().filter { username ->
        Cache.getRepos(username).any { it.name.contains(query, ignoreCase = true) }
    }

    if (matchingUsers.isEmpty()) {
        println("No repositories found.")
    } else {
        matchingUsers.forEach { username ->
            val user = Cache.getUser(username)
            println("Owner: ${user?.login}")
            println("Cached user: $user")
            val cachedRepos = Cache.getRepos(username)
            println("Cached Repositories (${cachedRepos.size}):")
            cachedRepos.forEach { repo -> println("    ${repo.name} - ${repo.html_url}") }
        }
    }
}


