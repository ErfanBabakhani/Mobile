data class GitHubUser(val login: String, val followers: Int, val following: Int, val created_at: String)
data class Repository(val name: String, val html_url: String)
